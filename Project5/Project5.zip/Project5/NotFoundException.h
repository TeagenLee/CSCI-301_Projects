/*
This file creates the NotFoundException error.
dj5172pl Teagen Lee
Due: 10/24/2025
Dr. Jie Hu Meichsner
*/

//  Created by Frank M. Carrano and Timothy M. Henry.
//  Copyright (c) 2025 Pearson Education, Hoboken, New Jersey.

/** @file NotFoundException.h */

#ifndef NOT_FOUND_EXCEPTION_
#define NOT_FOUND_EXCEPTION_

#include <stdexcept>
#include <string>

class NotFoundException : public std::logic_error
{
public:
   NotFoundException(const std::string& message = "");
}; // end NotFoundException 

#include "NotFoundException.cpp"
#endif
